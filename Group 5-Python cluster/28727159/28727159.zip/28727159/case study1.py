import datetime
class Book:
    def __init__(self, book_id, title, author, genre, price, stock):
        self.book_id = book_id
        self.title = title
        self.author = author
        self.genre = genre
        self.price = price
        self.stock = stock

    def __repr__(self):
        return f"Book({self.book_id}, {self.title}, {self.author}, {self.genre}, {self.price}, {self.stock})"
class Order:
    def __init__(self, order_id, customer_id, book_id, quantity, order_date):
        self.order_id = order_id
        self.customer_id = customer_id
        self.book_id = book_id
        self.quantity = quantity
        self.order_date = order_date
    def __repr__(self):
        return f"Order({self.order_id}, {self.customer_id}, {self.book_id}, {self.quantity}, {self.order_date})"

class OnlineBookstore:
    def __init__(self):
        self.books = {}
        self.orders = {}
        self.next_book_id = 1
        self.next_order_id = 1

    def add_book(self, title, author, genre, price, stock):
        book = Book(self.next_book_id, title, author, genre, price, stock)
        self.books[self.next_book_id] = book
        self.next_book_id += 1
        print(f"Book added: {book}")

    def update_book(self, book_id, title=None, author=None, genre=None, price=None, stock=None):
        if book_id not in self.books:
            print(f"Book with ID {book_id} not found.")
            return
        book = self.books[book_id]
        if title:
            book.title = title
        if author:
            book.author = author
        if genre:
            book.genre = genre
        if price:
            book.price = price
        if stock:
            book.stock = stock
        print(f"Book updated: {book}")

    def delete_book(self, book_id):
        if book_id in self.books:
            del self.books[book_id]
            print(f"Book with ID {book_id} deleted.")
        else:
            print(f"Book with ID {book_id} not found.")

    def process_order(self, customer_id, book_id, quantity):
        if book_id not in self.books:
            print(f"Book with ID {book_id} not found.")
            return
        book = self.books[book_id]
        if book.stock < quantity:
            print(f"Not enough stock for book {book.title}.")
            return
        order_date = datetime.date.today()
        order = Order(self.next_order_id, customer_id, book_id, quantity, order_date)
        self.orders[self.next_order_id] = order
        book.stock -= quantity
        self.next_order_id += 1
        print(f"Order processed: {order}")

    def generate_low_stock_report(self):
        low_stock_books = [book for book in self.books.values() if book.stock < 5]
        if not low_stock_books:
            print("No books with low stock.")
        else:
            print("Low stock books:")
            for book in low_stock_books:
                print(book)

bookstore = OnlineBookstore()
bookstore.add_book("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", 10.99, 3)
bookstore.add_book("1984", "George Orwell", "Dystopian", 8.99, 10)
bookstore.update_book(1, stock=2)
bookstore.process_order(1, 1, 1)
bookstore.generate_low_stock_report()


