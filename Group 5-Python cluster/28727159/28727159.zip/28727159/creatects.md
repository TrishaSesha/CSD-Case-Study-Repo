# This file contains the queries that were used to create,insert and the answers for queries 

## Creation of the Customer Books Table
```
CREATE TABLE Books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100),
    author VARCHAR(100),
    genre VARCHAR(50),
    price DECIMAL(10, 2),
    stock INT
);
```

## Creation of the Customers Table
```
CREATE TABLE Customers (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100)
);
```

## Creation of the Orders Table
```
CREATE TABLE Orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    book_id INT,
    quantity INT,
    order_date DATE,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
    FOREIGN KEY (book_id) REFERENCES Books(book_id)
);

```
## Insertion of the Books Table
```
INSERT INTO Books (title, author, genre, price, stock) VALUES
('The Great Gatsby', 'F. Scott Fitzgerald', 'Fiction', 10.99, 3),
('1984', 'George Orwell', 'Dystopian', 8.99, 10),
('To Kill a Mockingbird', 'Harper Lee', 'Classic', 7.99, 0),
('Moby Dick', 'Herman Melville', 'Adventure', 11.50, 2),
('War and Peace', 'Leo Tolstoy', 'Historical', 12.99, 4);
```
## Insertion of the Customers Table
```
INSERT INTO Customers (name, email) VALUES
('Alice Johnson', 'alice@example.com'),
('Bob Smith', 'bob@example.com'),
('Carol White', 'carol@example.com'),
('David Black', 'david@example.com'),
('Eve Green', 'eve@example.com');
```
## Insertion of the Orders Table
```
INSERT INTO Orders (customer_id, book_id, quantity, order_date) VALUES
(1, 1, 1, '2023-07-01'),
(2, 2, 2, '2023-07-02'),
(3, 1, 1, '2023-07-03'),
(4, 4, 1, '2023-07-04'),
(5, 5, 3, '2023-07-05'),
(1, 2, 1, '2023-07-06'),
(2, 3, 1, '2023-07-07'),
(3, 4, 2, '2023-07-08'),
(4, 5, 1, '2023-07-09'),
(5, 1, 2, '2023-07-10');
```
## Find the total sales amount for each book:
```
SELECT b.title, SUM(o.quantity * b.price) AS total_sales
FROM Orders o
JOIN Books b ON o.book_id = b.book_id
GROUP BY b.title;
```
## Find the names of customers and their total order amounts:
```
SELECT c.name, SUM(o.quantity * b.price) AS total_order_amount
FROM Orders o
JOIN Customers c ON o.customer_id = c.customer_id
JOIN Books b ON o.book_id = b.book_id
GROUP BY c.name;
```
## Find the titles of books that have not been ordered:
```
SELECT b.title
FROM Books b
LEFT JOIN Orders o ON b.book_id = o.book_id
WHERE o.order_id IS NULL;
```
## Find the customers who have placed more than 5 orders:
```
SELECT c.name, COUNT(o.order_id) AS order_count
FROM Orders o
JOIN Customers c ON o.customer_id = c.customer_id
GROUP BY c.name
HAVING COUNT(o.order_id) > 5;
```
## Find the book titles and their current stock levels for books with stock less than 5:
```
SELECT title, stock
FROM Books
WHERE stock < 5;
```